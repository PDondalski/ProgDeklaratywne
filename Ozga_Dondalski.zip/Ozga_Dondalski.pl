%Zdefiniowanie element�w bazy gier poprzez dodanie rekod�w
%wyszczeg�lniaj�c istotne elementy

%U�ytkownik mo�e dowiedzie� si� przyk�adowo jakie gry s� dla dzieci czy
%w jakie gry mo�e zagra� osi�gaj�c 18 lat

%GATUNKI
%	fps
%	survival
%	karciane
%	hack_and_slash
%	wy�cigowe
%	horror
%	mmorpg
%	rpg

%TRYBY
%	single
%	multi
%	multi&single

%======================================================================
%GRY FPS
%======================================================================
gra(nazwa_gry('csgo'),gatunek('fps'),tryby('multi&single'),cena(0),pegi(18)).
gra(nazwa_gry('call_of_duty_4_modern_warfare'),gatunek('fps'),tryby('multi&single'),cena(84.91),pegi(16)).
gra(nazwa_gry('call_of_duty_modern_warfare_2'),gatunek('fps'),tryby('multi&single'),cena(84.91),pegi(18)).
gra(nazwa_gry('call_of_duty_black_ops'),gatunek('fps'),tryby('multi&single'),cena(169.86),pegi(18)).
gra(nazwa_gry('valorant'),gatunek('fps'),tryby('multi'),cena(0),pegi(16)).
gra(nazwa_gry('far_cry'),gatunek('fps'),tryby('single'),cena(39.90),pegi(16)).
gra(nazwa_gry('battlefield_1942'),gatunek('fps'),tryby('multi&single'),cena(40),pegi(16)).
gra(nazwa_gry('insurgency'),gatunek('fps'),tryby('multi'),cena(53.99),pegi(18)).
gra(nazwa_gry('arma_3'),gatunek('fps'),tryby('multi&single'),cena(119.99),pegi(16)).
gra(nazwa_gry('borderlands_3'),gatunek('fps'),tryby('multi&single'),cena(260),pegi(18)).
gra(nazwa_gry('borderlands_2'),gatunek('fps'),tryby('multi&single'),cena(128.90),pegi(18)).
gra(nazwa_gry('ready_or_not'),gatunek('fps'),tryby('multi&single'),cena(139.99),pegi(18)).
gra(nazwa_gry('prey'),gatunek('fps'),tryby('single'),cena(124),pegi(18)).
gra(nazwa_gry('deathloop'),gatunek('fps'),tryby('multi&single'),cena(249),pegi(18)).
gra(nazwa_gry('far_cry_3'),gatunek('fps'),tryby('single'),cena(79.90),pegi(18)).
gra(nazwa_gry('far_cry_4'),gatunek('fps'),tryby('single'),cena(119.90),pegi(18)).
gra(nazwa_gry('far_cry_6'),gatunek('fps'),tryby('multi&single'),cena(190),pegi(18)).
gra(nazwa_gry('postal_2'),gatunek('fps'),tryby('single'),cena(35.99),pegi(18)).
gra(nazwa_gry('postal_4'),gatunek('fps'),tryby('single'),cena(142.99),pegi(18)).
gra(nazwa_gry('stalker'),gatunek('fps'),tryby('single'),cena(71.99),pegi(18)).
gra(nazwa_gry('escape_from_tarkov'),gatunek('fps'),tryby('multi'),cena(139.84),pegi(18)).
gra(nazwa_gry('left_4_dead'),gatunek('fps'),tryby('multi&single'),cena(35.99),pegi(18)).
gra(nazwa_gry('halo_infinite'),gatunek('fps'),tryby('multi'),cena(0),pegi(16)).
gra(nazwa_gry('battlefield_2042'),gatunek('fps'),tryby('multi&single'),cena(269.90),pegi(18)).
gra(nazwa_gry('battlefield_2'),gatunek('fps'),tryby('multi&single'),cena(36),pegi(16)).
gra(nazwa_gry('battlefield_3'),gatunek('fps'),tryby('multi&single'),cena(36.99),pegi(18)).
gra(nazwa_gry('battlefield_4'),gatunek('fps'),tryby('multi&single'),cena(42.93),pegi(18)).
gra(nazwa_gry('shadow_warrior_3'),gatunek('fps'),tryby('single'),cena(179.99),pegi(18)).
gra(nazwa_gry('shadow_warrior_2'),gatunek('fps'),tryby('multi&single'),cena(142.99),pegi(18)).
gra(nazwa_gry('half_life_2'),gatunek('fps'),tryby('single'),cena(35.99),pegi(16)).
gra(nazwa_gry('half_life'),gatunek('fps'),tryby('multi&single'),cena(35.99),pegi(16)).
gra(nazwa_gry('fallout_4'),gatunek('fps'),tryby('single'),cena(79),pegi(18)).
gra(nazwa_gry('fallout_3'),gatunek('fps'),tryby('single'),cena(44.99),pegi(18)).
gra(nazwa_gry('star_wars_battlefront_2'),gatunek('fps'),tryby('multi&single'),cena(35.99),pegi(18)).
gra(nazwa_gry('doom_eternal'),gatunek('fps'),tryby('multi&single'),cena(169),pegi(18)).
gra(nazwa_gry('sniper_ghost_warrior_2'),gatunek('fps'),tryby('single'),cena(7.19),pegi(18)).
gra(nazwa_gry('overwatch'),gatunek('fps'),tryby('multi'),cena(199.43),pegi(12)).
gra(nazwa_gry('battlefield_V'),gatunek('fps'),tryby('multi&single'),cena(220),pegi(18)).
gra(nazwa_gry('battlefield_1'),gatunek('fps'),tryby('multi&single'),cena(44.97),pegi(18)).
gra(nazwa_gry('duke_nukem_forever'),gatunek('fps'),tryby('multi&single'),cena(85.90),pegi(18)).
gra(nazwa_gry('crysis_2'),gatunek('fps'),tryby('multi&single'),cena(119),pegi(18)).
gra(nazwa_gry('crysis_3'),gatunek('fps'),tryby('multi&single'),cena(119),pegi(18)).
gra(nazwa_gry('bioshock'),gatunek('fps'),tryby('single'),cena(85.90),pegi(18)).
gra(nazwa_gry('sniper_elite_v2'),gatunek('fps'),tryby('multi&single'),cena(35.99),pegi(16)).
gra(nazwa_gry('sniper_elite_3'),gatunek('fps'),tryby('multi&single'),cena(107.99),pegi(18)).
gra(nazwa_gry('sniper_elite_4'),gatunek('fps'),tryby('single'),cena(214.99),pegi(16)).
gra(nazwa_gry('serious_sam_siberian_mayhem'),gatunek('fps'),tryby('multi&single'),cena(80),pegi(18)).
gra(nazwa_gry('bioshock_infinite'),gatunek('fps'),tryby('single'),cena(128.90),pegi(18)).
gra(nazwa_gry('metro_last_light'),gatunek('fps'),tryby('single'),cena(71.99),pegi(18)).
gra(nazwa_gry('metro_exodus'),gatunek('fps'),tryby('single'),cena(127),pegi(18)).
gra(nazwa_gry('swat_4'),gatunek('gra_fps'),tryby('multi&single'),cena(40),pegi(18)).
gra(nazwa_gry('hell_let_loose'),gatunek('fps'),tryby('multi'),cena(142.99),pegi(18)).
gra(nazwa_gry('battlefield_bad_company_2'),gatunek('fps'),tryby('multi&single'),cena(35.99),pegi(18)).
gra(nazwa_gry('enlisted'),gatunek('fps'),tryby('multi&single'),cena(0),pegi(16)).
gra(nazwa_gry('pubg'),gatunek('fps'),tryby('multi'),cena(0),pegi(18)).
gra(nazwa_gry('team_fortress_2'),gatunek('fps'),tryby('multi'),cena(0),pegi(16)).
gra(nazwa_gry('rage'),gatunek('fps'),tryby('single'),cena(44.99),pegi(18)).
gra(nazwa_gry('rage_2'),gatunek('fps'),tryby('single'),cena(169),pegi(18)).
gra(nazwa_gry('rainbow_six_extraction'),gatunek('fps'),tryby('multi&single'),cena(189),pegi(16)).
gra(nazwa_gry('rainbow_six_siege'),gatunek('fps'),tryby('multi&single'),cena(79.90),pegi(18)).
gra(nazwa_gry('payday_2'),gatunek('fps'),tryby('multi&single'),cena(35.99),pegi(18)).
gra(nazwa_gry('deus_ex'),gatunek('fps'),tryby('single'),cena(40),pegi(18)).
gra(nazwa_gry('apex_legends'),gatunek('fps'),tryby('multi'),cena(0),pegi(16)).
gra(nazwa_gry('halo_4'),gatunek('fps'),tryby('multi&single'),cena(35.99),pegi(16)).
gra(nazwa_gry('star_wars_battlefront_2'),gatunek('fps'),tryby('multi&single'),cena(139.99),pegi(16)).
gra(nazwa_gry('star_wars_battlefront'),gatunek('fps'),tryby('multi&single'),cena(69.90),pegi(16)).
gra(nazwa_gry('halo_2'),gatunek('fps'),tryby('multi&single'),cena(35.99),pegi(16)).
gra(nazwa_gry('delta_force_helikopter_w_ogniu'),gatunek('fps'),tryby('multi&single'),cena(35.99),pegi(16)).
gra(nazwa_gry('homefront'),gatunek('fps'),tryby('single'),cena(71.99),pegi(18)).
gra(nazwa_gry('serious_sam_4'),gatunek('fps'),tryby('multi&single'),cena(142.99),pegi(18)).
gra(nazwa_gry('quake_2'),gatunek('fps'),tryby('single'),cena(20),pegi(18)).
gra(nazwa_gry('quake_4'),gatunek('fps'),tryby('single'),cena(64.99),pegi(18)).
%======================================================================
%GRY RPG
%======================================================================
gra(nazwa_gry('wiedzmin'),gatunek('rpg'),tryby('multi&single'),cena(29.99),pegi(18)).
gra(nazwa_gry('skyrim_V_special_edition'),gatunek('rpg'),tryby('single'),cena(169.99),pegi(18)).
gra(nazwa_gry('cyberpunk'),gatunek('rpg'),tryby('single'),cena(199),pegi(18)).
gra(nazwa_gry('assassins_creed'),gatunek('rpg'),tryby('single'),cena(35.99),pegi(18)).
gra(nazwa_gry('assassins_creed_odyssey'),gatunek('rpg'),tryby('single'),cena(249.99),pegi(18)).
gra(nazwa_gry('assassins_creed_origins'),gatunek('rpg'),tryby('single'),cena(249.90),pegi(18)).
gra(nazwa_gry('oblivion'),gatunek('rpg'),tryby('single'),cena(35.99),pegi(18)).
gra(nazwa_gry('divinity_original_sin_2'),gatunek('rpg'),tryby('multi&single'),cena(161.99),pegi(16)).
gra(nazwa_gry('mass_effect'),gatunek('rpg'),tryby('single'),cena(69.90),pegi(18)).
gra(nazwa_gry('mass_effect_2'),gatunek('rpg'),tryby('single'),cena(69.90),pegi(18)).
gra(nazwa_gry('pillars_of_eternity'),gatunek('rpg'),tryby('multi&single'),cena(107.99),pegi(16)).
gra(nazwa_gry('bastion'),gatunek('rpg'),tryby('single'),cena(53.99),pegi(12)).
gra(nazwa_gry('nier_automata'),gatunek('rpg'),tryby('single'),cena(142.99),pegi(18)).
gra(nazwa_gry('wasteland_3'),gatunek('rpg'),tryby('multi&single'),cena(71.38),pegi(18)).
gra(nazwa_gry('monster_hunter_world'),gatunek('rpg'),tryby('single'),cena(125),pegi(18)).
gra(nazwa_gry('elden_ring'),gatunek('rpg'),tryby('multi&single'),cena(249),pegi(18)).
gra(nazwa_gry('gothic'),gatunek('rpg'),tryby('single'),cena(39.99),pegi(16)).
gra(nazwa_gry('gothic_2'),gatunek('rpg'),tryby('single'),cena(39.99),pegi(12)).
gra(nazwa_gry('gothic_3'),gatunek('rpg'),tryby('single'),cena(39.99),pegi(16)).
gra(nazwa_gry('kingdom_come_deliverance'),gatunek('rpg'),tryby('single'),cena(107.99),pegi(18)).
gra(nazwa_gry('fallout_4'),gatunek('rpg'),tryby('single'),cena(71.99),pegi(18)).
gra(nazwa_gry('fallout_3'),gatunek('rpg'),tryby('single'),cena(44.99),pegi(18)).
gra(nazwa_gry('wiedzmin_2'),gatunek('rpg'),tryby('single'),cena(39.99),pegi(18)).
gra(nazwa_gry('wiedzmin_3'),gatunek('rpg'),tryby('single'),cena(99.99),pegi(18)).
gra(nazwa_gry('elex'),gatunek('rpg'),tryby('single'),cena(124.99),pegi(16)).
gra(nazwa_gry('elex_2'),gatunek('rpg'),tryby('single'),cena(209.99),pegi(18)).
gra(nazwa_gry('core_keeper'),gatunek('rpg'),tryby('multi&single'),cena(46.99),pegi(12)).
gra(nazwa_gry('dark_souls_remastered'),gatunek('rpg'),tryby('multi&single'),cena(149.90),pegi(16)).
gra(nazwa_gry('dark_souls_2'),gatunek('rpg'),tryby('multi&single'),cena(79.90),pegi(16)).
gra(nazwa_gry('dark_souls_3'),gatunek('rpg'),tryby('multi&single'),cena(199.90),pegi(16)).
gra(nazwa_gry('mass_effect_andromeda'),gatunek('rpg'),tryby('single'),cena(119.99),pegi(18)).
gra(nazwa_gry('risen'),gatunek('rpg'),tryby('single'),cena(35.99),pegi(18)).
gra(nazwa_gry('risen_2'),gatunek('rpg'),tryby('single'),cena(35.99),pegi(18)).
gra(nazwa_gry('demons_souls'),gatunek('rpg'),tryby('multi&single'),cena(325.99),pegi(18)).
gra(nazwa_gry('broken_ranks'),gatunek('rpg'),tryby('multi'),cena(0),pegi(16)).
gra(nazwa_gry('grim_dawn'),gatunek('rpg'),tryby('multi&single'),cena(35.99),pegi(18)).
%======================================================================
%GRY MMORPG
%======================================================================
gra(nazwa_gry('new_world'),gatunek('mmorpg'),tryby('multi'),cena(142.99),pegi(16)).
gra(nazwa_gry('margonem'),gatunek('mmorpg'),tryby('multi'),cena(0),pegi(18)).
gra(nazwa_gry('lost_ark'),gatunek('mmorpg'),tryby('multi&single'),cena(0),pegi(18)).
gra(nazwa_gry('destiny_2'),gatunek('mmorpg'),tryby('multi'),cena(0),pegi(18)).
gra(nazwa_gry('the_elder_scrolls_online'),gatunek('mmorpg'),tryby('multi'),cena(79.90),pegi(18)).
gra(nazwa_gry('black_desert_online'),gatunek('mmorpg'),tryby('multi'),cena(22.50),pegi(16)).
gra(nazwa_gry('valheim'),gatunek('mmorpg'),tryby('multi&single'),cena(71.99),pegi(16)).
gra(nazwa_gry('the_lords_of_the_rings_online'),gatunek('mmorpg'),tryby('multi'),cena(0),pegi(16)).
gra(nazwa_gry('secret_world_legends'),gatunek('mmorpg'),tryby('multi'),cena(0),pegi(16)).
gra(nazwa_gry('star_wars_the_old_republic'),gatunek('mmorpg'),tryby('multi'),cena(0),pegi(16)).
gra(nazwa_gry('age_of_conan_unchained'),gatunek('mmorpg'),tryby('multi'),cena(0),pegi(18)).
gra(nazwa_gry('albion_online'),gatunek('mmorpg'),tryby('multi'),cena(0),pegi(18)).
gra(nazwa_gry('metin_2'),gatunek('mmorpg'),tryby('multi'),cena(0),pegi(12)).
gra(nazwa_gry('eve_online'),gatunek('mmorpg'),tryby('multi'),cena(0),pegi(12)).
gra(nazwa_gry('neverwinter'),gatunek('mmorpg'),tryby('multi&single'),cena(0),pegi(12)).
gra(nazwa_gry('tera'),gatunek('mmorpg'),tryby('multi&single'),cena(0),pegi(12)).
%======================================================================
%GRY SURVIVAL
%======================================================================
gra(nazwa_gry('valheim'),gatunek('survival'),tryby('multi&single'),cena(71.99),pegi(18)).
gra(nazwa_gry('the_forest'),gatunek('survival'),tryby('multi&single'),cena(50.99),pegi(18)).
gra(nazwa_gry('green_hell'),gatunek('survival'),tryby('multi&single'),cena(80),pegi(18)).
gra(nazwa_gry('minecraft'),gatunek('survival'),tryby('multi&single'),cena(120),pegi(7)).
gra(nazwa_gry('subnautica'),gatunek('survival'),tryby('multi&single'),cena(35.99),pegi(16)).
gra(nazwa_gry('ark'),gatunek('survival'),tryby('multi&single'),cena(107.99),pegi(18)).
gra(nazwa_gry('dont_starve'),gatunek('survival'),tryby('multi&single'),cena(53.99),pegi(18)).
gra(nazwa_gry('darkwood'),gatunek('survival'),tryby('single'),cena(39.99),pegi(18)).
gra(nazwa_gry('they_are_billions'),gatunek('survival'),tryby('single'),cena(107.99),pegi(18)).
gra(nazwa_gry('frostpunk'),gatunek('survival'),tryby('single'),cena(109.99),pegi(16)).
gra(nazwa_gry('outward'),gatunek('survival'),tryby('multi&single'),cena(179.99),pegi(16)).
gra(nazwa_gry('this_war_of_mine'),gatunek('survival'),tryby('single'),cena(59.99),pegi(16)).
%======================================================================
%GRY HORROR
%======================================================================
gra(nazwa_gry('silent_hill'),gatunek('horror'),tryby('multi&single'),cena(99.99),pegi(18)).
gra(nazwa_gry('resident_evil'),gatunek('horror'),tryby('multi&single'),cena(109.99),pegi(18)).
gra(nazwa_gry('soma'),gatunek('horror'),tryby('multi&single'),cena(49.99),pegi(18)).
gra(nazwa_gry('inside'),gatunek('horror'),tryby('multi&single'),cena(35.99),pegi(18)).
gra(nazwa_gry('the_evil_within'),gatunek('horror'),tryby('multi&single'),cena(156.99),pegi(18)).
gra(nazwa_gry('the_sinking_city'),gatunek('horror'),tryby('single'),cena(142.99),pegi(18)).
gra(nazwa_gry('little_nightmares'),gatunek('horror'),tryby('single'),cena(79.99),pegi(16)).
gra(nazwa_gry('obcy_izolacja'),gatunek('horror'),tryby('single'),cena(79.99),pegi(18)).
gra(nazwa_gry('the_medium'),gatunek('horror'),tryby('single'),cena(179.99),pegi(18)).
gra(nazwa_gry('carrion'),gatunek('horror'),tryby('single'),cena(71.99),pegi(18)).
gra(nazwa_gry('alan_wake'),gatunek('horror'),tryby('single'),cena(53.99),pegi(18)).
gra(nazwa_gry('hidden_deep'),gatunek('horror'),tryby('multi&single'),cena(59.99),pegi(18)).
gra(nazwa_gry('layers_of_fear'),gatunek('horror'),tryby('single'),cena(59.99),pegi(16)).
gra(nazwa_gry('the_price_of_flesh'),gatunek('horror'),tryby('single'),cena(53.99),pegi(18)).
%======================================================================
%GRY WY�CIGOWE
%======================================================================
gra(nazwa_gry('forza_horizon'),gatunek('wyscigi'),tryby('multi&single'),cena(249.99),pegi(16)).
gra(nazwa_gry('burnout'),gatunek('wyscigi'),tryby('multi&single'),cena(35.99),pegi(16)).
gra(nazwa_gry('need_for_speed'),gatunek('wyscigi'),tryby('multi&single'),cena(50),pegi(16)).
gra(nazwa_gry('gran_turismo_7'),gatunek('wyscigi'),tryby('multi&single'),cena(200.99),pegi(16)).
gra(nazwa_gry('dirt_rally'),gatunek('wyscigi'),tryby('multi&single'),cena(71.99),pegi(16)).
gra(nazwa_gry('burnout_paradise_remastered'),gatunek('wyscigi'),tryby('multi&single'),cena(74.99),pegi(16)).
gra(nazwa_gry('wrc_10'),gatunek('wyscigi'),tryby('multi&single'),cena(169.99),pegi(16)).
gra(nazwa_gry('crash_team_racing_nitro_fueled'),gatunek('wyscigi'),tryby('multi&single'),cena(135.99),pegi(3)).
gra(nazwa_gry('mario_kart_8_deluxe'),gatunek('wyscigi'),tryby('multi&single'),cena(218.72),pegi(3)).
gra(nazwa_gry('f1_2021'),gatunek('wyscigi'),tryby('multi&single'),cena(139.99),pegi(3)).
gra(nazwa_gry('forza_motorsport_7'),gatunek('wyscigi'),tryby('multi&single'),cena(81.78),pegi(3)).
gra(nazwa_gry('asseto_corsa_competizione'),gatunek('wyscigi'),tryby('multi&single'),cena(135.90),pegi(3)).
gra(nazwa_gry('rims_racing'),gatunek('wyscigi'),tryby('multi&single'),cena(179.99),pegi(3)).
gra(nazwa_gry('ride_4'),gatunek('wyscigi'),tryby('multi&single'),cena(219.99),pegi(3)).
gra(nazwa_gry('project_cars_3'),gatunek('wyscigi'),tryby('multi&single'),cena(243.99),pegi(3)).
gra(nazwa_gry('team_sonic_racing'),gatunek('wyscigi'),tryby('multi&single'),cena(169.99),pegi(7)).
gra(nazwa_gry('the_crew_2'),gatunek('wyscigi'),tryby('multi&single'),cena(199.99),pegi(12)).
%======================================================================
%GRY HACK AND SLASH
%======================================================================
gra(nazwa_gry('diablo'),gatunek('hack_and_slash'),tryby('multi&single'),cena(35.99),pegi(18)).
gra(nazwa_gry('path_of_exile'),gatunek('hack_and_slash'),tryby('multi&single'),cena(35.99),pegi(18)).
gra(nazwa_gry('grim_dawn'),gatunek('hack_and_slash'),tryby('multi&single'),cena(35.99),pegi(18)).
gra(nazwa_gry('book_of_demons'),gatunek('hack_and_slash'),tryby('multi&single'),cena(35.99),pegi(18)).
gra(nazwa_gry('titan_quest'),gatunek('hack_and_slash'),tryby('multi&single'),cena(35.99),pegi(18)).
gra(nazwa_gry('minecraft_dungeons'),gatunek('hack_and_slash'),tryby('multi&single'),cena(35.99),pegi(18)).
gra(nazwa_gry('vikings_wolves_of_midgard'),gatunek('hack_and_slash'),tryby('multi&single'),cena(35.99),pegi(18)).
gra(nazwa_gry('titan_quest'),gatunek('hack_and_slash'),tryby('multi&single'),cena(35.99),pegi(18)).
gra(nazwa_gry('hades'),gatunek('hack_and_slash'),tryby('multi&single'),cena(35.99),pegi(18)).
gra(nazwa_gry('darksiders_genesis'),gatunek('hack_and_slash'),tryby('multi&single'),cena(35.99),pegi(18)).
%======================================================================
%GRY KARCIANE
%======================================================================
gra(nazwa_gry('gwint'),gatunek('karcianka'),tryby('multi&single'),cena(35.99),pegi(18)).
gra(nazwa_gry('magic_2014'),gatunek('karcianka'),tryby('multi&single'),cena(35.99),pegi(18)).
gra(nazwa_gry('hearthstone'),gatunek('karcianka'),tryby('multi&single'),cena(35.99),pegi(18)).
gra(nazwa_gry('faeria'),gatunek('karcianka'),tryby('multi&single'),cena(35.99),pegi(18)).
gra(nazwa_gry('legends_of_runeterra'),gatunek('karcianka'),tryby('multi&single'),cena(35.99),pegi(18)).
gra(nazwa_gry('cardpocalypse'),gatunek('karcianka'),tryby('single'),cena(93.49),pegi(12)).
%======================================================================
%Sortowanie i wybieranie konkretnych danych z bazy
%======================================================================


%szukaj(Nazwa,Gatunek,Tryby,Cena,Pegi). -  wypisuje ka�d� gre w bazie
%szukaj(Nazwa,fps,_,_,_). - Wypisuje ka�d� gre z podnaego gatunku
szukaj(Nazwa,Gatunek,Tryby,Cena,Pegi):-gra(nazwa_gry(Nazwa),gatunek(Gatunek),tryby(Tryby),cena(Cena),pegi(Pegi)).
%cena_w30(Nazwa,_,_,Cena,_). - Gry o cenie wi�kszej ni� 30 z�
cena_w30(Nazwa,Gatunek,Tryby,Cena,Pegi):-gra(nazwa_gry(Nazwa),gatunek(Gatunek),tryby(Tryby),cena(Cena),pegi(Pegi)),
	Cena>30.
%cena_m30(Nazwa,_,_,Cena,_). - Gry o cenie mniejszej ni� 30 z�
cena_m30(Nazwa,Gatunek,Tryby,Cena,Pegi):-gra(nazwa_gry(Nazwa),gatunek(Gatunek),tryby(Tryby),cena(Cena),pegi(Pegi)),
	Cena<31.
%dla_dzieci(Nazwa,Gatunek,_,_,Pegi). - Gry dla dzieci
dla_dzieci(Nazwa,Gatunek,Tryby,Cena,Pegi):-gra(nazwa_gry(Nazwa),gatunek(Gatunek),tryby(Tryby),cena(Cena),pegi(Pegi)),
	Pegi>2,Pegi<8.
%dla_m�odzie�y(Nazwa,Gatunek,_,_,Pegi). - Gry dla m�odzie�y
dla_m�odzie�y(Nazwa,Gatunek,Tryby,Cena,Pegi):-gra(nazwa_gry(Nazwa),gatunek(Gatunek),tryby(Tryby),cena(Cena),pegi(Pegi)),
	Pegi>11,Pegi<17.
%dla_doros�ych(Nazwa,Gatunek,_,_,Pegi). - Gry dla doros�ych
dla_doros�ych(Nazwa,Gatunek,Tryby,Cena,Pegi):-gra(nazwa_gry(Nazwa),gatunek(Gatunek),tryby(Tryby),cena(Cena),pegi(Pegi)),
	Pegi>16,Pegi<19.
%single(Nazwa,_,Tryby,_,_). - Gry dla doros�ych
single(Nazwa,Gatunek,Tryby,Cena,Pegi):-gra(nazwa_gry(Nazwa),gatunek(Gatunek),tryby(Tryby),cena(Cena),pegi(Pegi)),
	Tryby==single.
%multi(Nazwa,_,Tryby,_,_). - Gry dla doros�ych
multi(Nazwa,Gatunek,Tryby,Cena,Pegi):-gra(nazwa_gry(Nazwa),gatunek(Gatunek),tryby(Tryby),cena(Cena),pegi(Pegi)),
	Tryby==multi.
%multi_single(Nazwa,_,Tryby,_,_). - Gry dla doros�ych
multi_single(Nazwa,Gatunek,Tryby,Cena,Pegi):-gra(nazwa_gry(Nazwa),gatunek(Gatunek),tryby(Tryby),cena(Cena),pegi(Pegi)),
	Tryby=='multi&single'.
%dla_m�odzie�y_nie(Nazwa,_,_,_,Pegi).
dla_m�odzie�y_nie(Nazwa,Gatunek,Tryby,Cena,Pegi):-gra(nazwa_gry(Nazwa),gatunek(Gatunek),tryby(Tryby),cena(Cena),pegi(Pegi)),
	Pegi>11,Pegi<17, dif(Gatunek, survival).

%gatunek_opis(fps). - Wpisujac dany gatunek gry otrzymamy kr�tki opis
gatunek_opis(fps):-
    write('Strzelanka pierwszoosobowa, FPS (od ang. first-person shooter) � gatunek
           gier komputerowych skoncentrowanych na walce z przewa�aj�cym zastosowaniem
           broni palnej, kt�rych akcja obserwowana jest z perspektywy pierwszej osoby.
           Innymi s�owy, gracz do�wiadcza akcji oczami g��wnego bohatera, kt�ry zazwyczaj
           widzi tylko r�ce i bro� postaci, natomiast pozosta�e cz�ci cia�a widoczne s�
           tylko na filmach obja�niaj�cych fabu��.').

gatunek_opis(rpg):-
    write('Komputerowa gra fabularna (ang. computer role-playing game, w skr�cie cRPG) � gatunek
           gier komputerowych, w kt�rym gracz kontroluje bohatera (lub dru�yn�) poruszaj�cego si�
           po najcz�ciej fikcyjnym �wiecie. Cz�sto gracz tworzy w�asn� posta�, okre�laj�c jej
           cechy i wygl�d zewn�trzny. W trakcie rozgrywki mo�na pomaga� postaciom niezale�nym i
           zabija� przeciwnik�w, dzi�ki czemu awansuje si� na kolejne poziomy i zdobywa nowe
           umiej�tno�ci. Komputerowa gra fabularna mo�e rozgrywa� si� w r�nych
           konwencjach, np. fantasy, science fiction czy steampunk.').

gatunek_opis(mmorpg):-
    write('MMORPG (skr�t od Massively multiplayer online role-playing game) � rodzaj
           komputerowych gier fabularnych, w kt�rych du�a liczba graczy mo�e gra� ze
           sob� w wirtualnym �wiecie. Podobnie jak w innych rodzajach gier
           fabularnych, gracz wciela si� w posta� i kieruje jej dzia�aniami.').

gatunek_opis(survival):-
    write('Komputerowa gra survivalowa � podgatunek komputerowej gry akcji, kt�rego rozgrywk�
           najcz�ciej cechuje otwarty �wiat, a zadaniem gracza jest przetrwanie.
		   Gracz rozpoczyna gr� w nieprzyjaznym �wiecie i z minimalnymi zasobami
           pozwalaj�cymi na przetrwanie. Jego zadaniem jest szukanie i zbieranie kolejnych
           zasob�w, narz�dzi czy broni, ale r�wnie� zaspokajanie potrzeb takich jak
           jedzenie, pragnienie, bezpiecze�stwo czy schronienie. Wiele produkcji tego
           typu jest opartych na losowo lub proceduralnie generowanych �rodowiskach, gry
           te nie maj� r�wnie� za�o�onych cel�w').

gatunek_opis(horror):-
    write('Survival horror � podgatunek przygodowych gier akcji oraz gier grozy inspirowany
           fantastyk� grozy, w kt�rym g��wnym celem jest utrzymanie bohatera przy �yciu.
           Nazwa survival-horror zosta�a pierwszy raz u�yta przez firm� Capcom w 1996 podczas
           reklamowania Resident Evil.
		   Gracz cz�sto jest podatny na zranienie i posiada ma�� liczb�
           przedmiot�w, co k�adzie nacisk na rozwi�zywanie zagadek i unikanie walki. Gry typu
           survival horror zazwyczaj wymagaj� racjonowania przedmiot�w takich jak amunicja.
           Poziomy nierzadko s� zaprojektowane jako ciemne i klaustrofobiczne (cz�sto z
           wykorzystaniem ciemnych lub zacienionych warunk�w o�wietlenia i kamery, kt�ra
           ogranicza widoczno��) w celu utrzymania gracza w napi�ciu').

gatunek_opis(wy�cigowe):-
    write('Komputerowa gra wy�cigowa � gatunek gier komputerowych polegaj�cy na �ciganiu si�
           pojazdami z przeciwnikami sterowanymi przez komputer lub z osob� lub osobami
           siedz�cym obok (tzw. podzielony ekran), b�d� przez sieci Internet lub sie� lokaln�.
           Gracze staraj� si� zdoby� jak najwy�sze miejsce lub przejecha� wyznaczon� tras� w
           najkr�tszym mo�liwym czasie').

gatunek_opis(hack_and_slash):-
    write('Hack and slash lub hack�n�slash (z angielskiego hack � r�ba� i slash � ci��) � termin
           stosowany jako nazwa gatunku gier komputerowych lub stylu grania w RPG, w kt�rych
           dominuj�c� rol� w rozgrywce odgrywa zabijanie potwor�w, zdobywanie do�wiadczenia i
           rozbudowywanie statystyk postaci.Termin u�ywany jest g��wnie do wyodr�bnienia
           tego rodzaju gier z rozgrywek gier fabularnych i cRPG, w kt�rych walka i pokonywanie
           potwor�w nie stanowi dominuj�cego elementu rozgrywki. Rozr�nienie mi�dzy grami
           typu hack and slash a grami cRPG bywa przedmiotem kontrowersji.').

gatunek_opis(karciane):-
    write('Gra z udzia�em co najmniej dw�ch uczestnik�w, w kt�rej u�ywa si� kart do gry.
           W dobie komputeryzacji du�a cz�� gier karcianych zosta�a przeniesiona na nasz ekrany komputer�w.
           Aktualnie powstaj� tytu�y kt�re ca�kowicie odchodz� od tradycyjnych zasad rozgrywek karcianych na rzecz
           wi�kszej rywalizacji w np. rankingu globalnym.').
